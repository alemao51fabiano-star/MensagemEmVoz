package br.com.mensagememvoz;

import android.content.ComponentName;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.speech.tts.TextToSpeech;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    private TextToSpeech tts;
    private TextView status;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        status = findViewById(R.id.status);
        Button accessibility = findViewById(R.id.accessibility);
        Button test = findViewById(R.id.test);
        Button slower = findViewById(R.id.slower);

        tts = new TextToSpeech(this, result -> {
            if (result == TextToSpeech.SUCCESS) {
                tts.setLanguage(new Locale("pt", "BR"));
            }
        });

        accessibility.setOnClickListener(v -> {
            startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
        });

        test.setOnClickListener(v -> speak("Olá! Este é o teste do aplicativo Mensagem em Voz."));
        slower.setOnClickListener(v -> {
            if (tts != null) tts.setSpeechRate(0.65f);
            speak("Esta é uma mensagem falada mais devagar.");
            if (tts != null) tts.setSpeechRate(1.0f);
        });
    }

    private void speak(String text) {
        if (tts != null) {
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "mensagem_em_voz");
            status.setText("🔊 Falando...");
        }
    }

    @Override
    protected void onDestroy() {
        if (tts != null) {
            tts.stop();
            tts.shutdown();
        }
        super.onDestroy();
    }
}
