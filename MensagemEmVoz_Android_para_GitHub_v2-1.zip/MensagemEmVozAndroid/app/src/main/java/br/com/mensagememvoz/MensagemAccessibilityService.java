package br.com.mensagememvoz;

import android.accessibilityservice.AccessibilityService;
import android.speech.tts.TextToSpeech;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import java.util.Locale;

public class MensagemAccessibilityService extends AccessibilityService {
    private static final String WHATSAPP = "com.whatsapp";
    private TextToSpeech tts;
    private long lastSpokenAt = 0;
    private String lastText = "";

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        tts = new TextToSpeech(this, result -> {
            if (result == TextToSpeech.SUCCESS) {
                tts.setLanguage(new Locale("pt", "BR"));
                tts.setSpeechRate(1.0f);
            }
        });
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null || !WHATSAPP.equals(event.getPackageName())) return;

        // Só tenta falar quando há uma ação de seleção/clique iniciada pelo usuário.
        int type = event.getEventType();
        if (type != AccessibilityEvent.TYPE_VIEW_CLICKED &&
            type != AccessibilityEvent.TYPE_VIEW_SELECTED) return;

        String text = extractText(event);
        if (text.isEmpty()) {
            AccessibilityNodeInfo source = event.getSource();
            text = findUsefulText(source);
            if (source != null) source.recycle();
        }

        if (text.isEmpty()) return;

        // Evita repetir a mesma mensagem várias vezes em sequência.
        long now = System.currentTimeMillis();
        if (text.equals(lastText) && now - lastSpokenAt < 2500) return;

        lastText = text;
        lastSpokenAt = now;

        if (tts != null) {
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "whatsapp_message");
        }
    }

    private String extractText(AccessibilityEvent event) {
        StringBuilder out = new StringBuilder();
        for (CharSequence part : event.getText()) {
            if (part != null) {
                String s = part.toString().trim();
                if (!s.isEmpty()) {
                    if (out.length() > 0) out.append(" ");
                    out.append(s);
                }
            }
        }
        return out.toString().trim();
    }

    private String findUsefulText(AccessibilityNodeInfo node) {
        if (node == null) return "";

        CharSequence text = node.getText();
        if (text != null && !text.toString().trim().isEmpty()) {
            return text.toString().trim();
        }

        CharSequence desc = node.getContentDescription();
        if (desc != null && !desc.toString().trim().isEmpty()) {
            return desc.toString().trim();
        }

        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            String found = findUsefulText(child);
            if (child != null) child.recycle();
            if (!found.isEmpty()) return found;
        }
        return "";
    }

    @Override
    public void onInterrupt() {
        if (tts != null) tts.stop();
    }

    @Override
    public void onDestroy() {
        if (tts != null) {
            tts.stop();
            tts.shutdown();
        }
        super.onDestroy();
    }
}
