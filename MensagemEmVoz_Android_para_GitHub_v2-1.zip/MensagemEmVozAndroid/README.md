# Mensagem em Voz — primeira versão Android

## O que esta versão faz
- Tela com botões grandes.
- Abre as configurações de Acessibilidade do Android.
- Testa a voz em português do Brasil.
- Inclui um `AccessibilityService` configurado para observar ações do usuário no WhatsApp.
- Quando uma mensagem de texto é disponibilizada pelo WhatsApp ao serviço em um evento de clique/seleção, tenta falar o texto.

## Limitação importante
Esta primeira versão é um protótipo técnico. O WhatsApp pode disponibilizar o texto de maneiras diferentes conforme a versão, o aparelho e a interface. Por isso, o comportamento de "tocar na mensagem e falar" precisa ser testado em aparelhos reais.

## Como abrir
1. Instale o Android Studio.
2. Abra a pasta `MensagemEmVozAndroid`.
3. Aguarde o Gradle sincronizar.
4. Conecte um celular Android com Depuração USB ou use um emulador.
5. Execute o aplicativo.
6. Dentro do aplicativo, toque em `ATIVAR ACESSIBILIDADE`.
7. Em Acessibilidade, procure `Mensagem em Voz` e ative.

O serviço de acessibilidade precisa ser ativado manualmente pelo usuário nas configurações do Android.

## Próximas melhorias
- Detectar com mais precisão somente bolhas de mensagem do WhatsApp.
- Evitar falar nomes de contatos, botões e outros textos da tela.
- Criar um botão flutuante "OUVIR" se o teste mostrar que isso é melhor para o usuário.
- Adicionar seleção de velocidade e voz.
- Testar Android 12–16 e diferentes versões do WhatsApp.
